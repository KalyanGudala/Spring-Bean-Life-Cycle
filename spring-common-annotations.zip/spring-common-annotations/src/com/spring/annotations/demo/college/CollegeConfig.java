package com.spring.annotations.demo.college;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;

@Configuration
@ComponentScan(basePackages ="com.spring.annotations.demo.college")
@PropertySource("classpath:college-info.properties")
public class CollegeConfig {

	//@Bean(name= {"colBean","collegeAnotherBean"})
	
	/*@Bean
	public Teacher mathTeachBean()
	{
		return new MathTeacher();
	}
	
	@Bean
	public Principal principalBean()
	{
		return new Principal();
	}
	
	
	@Bean
	public College collegeBean() //collegeBean is my beanId
	{
		//College college=new College(principalBean());
		College college=new College();
		college.setPrinicpal(principalBean());
		college.setTeacher(mathTeachBean());
		return college;
	}	*/
	
}
