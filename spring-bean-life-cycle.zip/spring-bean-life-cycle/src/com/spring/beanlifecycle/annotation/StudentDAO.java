package com.spring.beanlifecycle.annotation;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

public class StudentDAO {

	private String driver;
	private String url;
	private String username;
	private String password;
	Connection con;

	public String getDriver() {
		return driver;
	}

	public void setDriver(String driver) {
		System.out.println("Setting the drivers ####");
		this.driver = driver;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		System.out.println("Setting the url ####");
		this.url = url;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		System.out.println("Setting the username ####");
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		System.out.println("Setting the password ####");
		this.password = password;
	}

	// @PostConstruct
	public void init() throws ClassNotFoundException, SQLException {
		System.out.println("Inside the custom init() method::######");
		createStudentDBConnection();
	}

	// @PostConstruct
	public void createStudentDBConnection() throws ClassNotFoundException, SQLException {

		System.out.println("Creating connection for a Student DB::#########");
		// load Driver
		Class.forName(driver);

		// get a Connection
		con = DriverManager.getConnection(url, username, password);
	}

	public void selectAllRows() throws ClassNotFoundException, SQLException {

		System.out.println("Retrieveing all the Student Details from Students Table::");

		// createStudentDBConnection();

		// executeQuery
		Statement stm = con.createStatement();

		ResultSet rs = stm.executeQuery("select* from Student");

		while (rs.next()) {
			int studentId = rs.getInt(1);
			String studentName = rs.getString(2);
			double hostelFees = rs.getDouble(3);
			String fooDType = rs.getString(4);

			System.out.println(studentId + " " + studentName + " " + hostelFees + " " + fooDType + " ");

		}

	}

	public void deleteStudentRecord(int studentId) throws ClassNotFoundException, SQLException {

		System.out.println("Deleting the Student Record from  the  Students Table::");

		// createStudentDBConnection();
		// executeQuery
		Statement stm = con.createStatement();

		stm.executeUpdate("delete from Student where student_id=" + studentId);

		System.out.println("Record deleted with studentId is: " + studentId);

	}

	// @PreDestroy
	public void closeConnection() throws SQLException {
		// Do some clean up jobs or removing unused variables like db connection close
		// After performing DB operations

		// Closing the connection
		con.close();
	}

	// @PreDestroy
	public void destroy() throws SQLException {
		System.out.println("Inside Destroy Method is called..###");
		closeConnection();
	}
}
