package com.springdemo.loosecoupling.dependencyinjec;

public class ScienceCheat implements Cheat {

	
	public void cheat()
	{
		System.out.println("Science Cheat started...!!");
	}
}
