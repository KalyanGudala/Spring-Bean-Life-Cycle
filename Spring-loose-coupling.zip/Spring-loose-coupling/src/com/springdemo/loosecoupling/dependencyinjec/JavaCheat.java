package com.springdemo.loosecoupling.dependencyinjec;

public class JavaCheat implements Cheat{

	@Override
	public void cheat() {
		System.out.println("java Cheating started..!!");
		
	}
	
	

}
