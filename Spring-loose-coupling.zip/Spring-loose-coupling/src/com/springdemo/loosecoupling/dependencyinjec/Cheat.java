package com.springdemo.loosecoupling.dependencyinjec;

public interface Cheat {

	public void cheat();
}
