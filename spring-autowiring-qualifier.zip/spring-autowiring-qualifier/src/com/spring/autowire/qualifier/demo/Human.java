package com.spring.autowire.qualifier.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Human {

	@Autowired
	@Qualifier("humanHeart")
	private Heart heart;

	/*public Human() {

	}

	// @Autowired
	public Human(Heart heart) {
		this.heart = heart;
		System.out.println("Human class Heart arg constructor is called...!!");
	}

	// @Autowired
	// @Qualifier("humanHeart")
	public void setHeart(Heart heart) {
		this.heart = heart;
		System.out.println("Human Method setter() is called..!!!");
	}*/

	public void startPumping() {
		if (heart != null) {
			heart.pump();
			System.out.println("name of the animal is::" + heart.getNameOfAnimal() + "no of heart present::"
					+ heart.getNoOfHeart());
		} else {
			System.out.println("You are dead..!!");
		}

	}

}
