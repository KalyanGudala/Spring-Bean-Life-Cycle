package com.spring.annotations.demo.college;

public interface Teacher {
	
	public void teach();

}
