package com.springdemo.loosecoupling.dependencyinjec;

public class MathCheat implements Cheat {
	
	
	public void cheat()
	{
		System.out.println("math cheating started...");
	}

}
