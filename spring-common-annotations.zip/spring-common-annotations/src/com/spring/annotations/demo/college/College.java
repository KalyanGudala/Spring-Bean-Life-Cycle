package com.spring.annotations.demo.college;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

//@Component("collegeBean")

@Component
public class College {
	
	//@Value("SpringTutorials")
   //@Value("${college.Name}")
	private String collegeName;
	
	@Autowired
	private Principal prinicpal;
	
	@Autowired
	@Qualifier("scienceTeacher")
	private Teacher teacher;
	
	
	/*public College(Principal prinicpal) {
		this.prinicpal = prinicpal;
	}
	*/
	
	public void test()
	{
		prinicpal.principalInfo();
		teacher.teach();
		System.out.println("My College name is:::"+ collegeName);
		System.out.println("testing this college Method...!!");
	}

	@Required
	@Value("${college.Name}")
	public void setCollegeName(String collegeName) {
		this.collegeName = collegeName;
	}

	
	/*public void setPrinicpal(Principal prinicpal) {
		this.prinicpal = prinicpal;
		System.out.println("using setPrinicpal method in College class");
	}

	
	public void setTeacher(Teacher teacher) {
		this.teacher = teacher;
	}
	*/	
	
}
