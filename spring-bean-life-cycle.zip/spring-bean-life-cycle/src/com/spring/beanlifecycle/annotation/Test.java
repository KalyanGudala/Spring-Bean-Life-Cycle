package com.spring.beanlifecycle.annotation;

import java.sql.SQLException;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {

		//ApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		//AbstractApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
		//context.registerShutdownHook();
		StudentDAO studentDao = context.getBean("studentDao", StudentDAO.class);
		System.out.println(studentDao);
		studentDao.selectAllRows();
		//((ClassPathXmlApplicationContext)context).close();//DownCatsing
		Hello hello=context.getBean("hello", Hello.class);
		//hello.sample();
		context.close();

		//StudentDAO studentDao1 = context.getBean("studentDao", StudentDAO.class);

	}
}
