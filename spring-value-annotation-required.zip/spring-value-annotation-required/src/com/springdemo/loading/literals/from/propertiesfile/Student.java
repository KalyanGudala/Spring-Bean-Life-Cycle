package com.springdemo.loading.literals.from.propertiesfile;

import org.springframework.beans.factory.annotation.Required;
import org.springframework.beans.factory.annotation.Value;

public class Student {

	@Value("${student.name}")
	private String name;
	
	@Value("${student.interestedCourse}")
	private String interestedCourse;
	
	@Value("${student.hobby}")
	private String hobby;
	
	//@Value("${student.name}")
	/*public void setName(String name) {
		this.name = name;
		System.out.println("Using the setName Method");
	}*/
	
	//@Required
	/*@Value("${student.interestedCourse}")
	public void setInterestedCourse(String interestedCourse) {
		this.interestedCourse = interestedCourse;
		System.out.println("Using the setInterestedCourse");
	}*/
	
	//@Required
	/*@Value("${student.hobby}")
	public void setHobby(String hobby) {
		this.hobby = hobby;
		System.out.println("Using the setHobby");
	}*/
	
	public void displayStudentInfo()
	{
		System.out.println("Student Name is::"+name);
		System.out.println("Student Intersted Course::"+interestedCourse);
		System.out.println("Student Hobby is::"+hobby);
	}
	
}
