package com.spring.annotations.demo.college;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
//@Primary
public class MathTeacher implements Teacher {

	@Override
	public void teach() {
		System.out.println("Hi, I am here your Math Teacher..!!");
		System.out.println("My Name is Saurav..!!");
	}

}
