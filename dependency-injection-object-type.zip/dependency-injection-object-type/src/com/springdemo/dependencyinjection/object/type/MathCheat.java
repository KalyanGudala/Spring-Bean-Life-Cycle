package com.springdemo.dependencyinjection.object.type;

public class MathCheat {
	
	public MathCheat()
	{
		System.out.println("Math Cheat class constructor called...");
	}
	
	public void mathCheat()
	{
		System.out.println("math cheating started...");
	}

}
