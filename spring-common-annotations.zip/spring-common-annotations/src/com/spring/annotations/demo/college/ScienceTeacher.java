package com.spring.annotations.demo.college;

import org.springframework.stereotype.Component;

@Component
public class ScienceTeacher implements Teacher {

	@Override
	public void teach() {
		System.out.println("Hi, I am here your Science Teacher..!!");
		System.out.println("My Name is Dravid..!!");
	}

}
